$('.colorbutton').on("click", function () {
    var bronny = $(this).html();
    console.log(bronny);
    $('.phonebody-internal').attr('id', $(this).text());
    $('.phonebody-internal1').attr('id', $(this).text());

    var $a1 = $('.flex-name');
    var $a2 = $('.flex-bio');
    var $a3 = $('.button-area');
    var $a4 = $('.button-area1');
    if (bronny === "purewhite") {
        $a1.addClass('black');
        $a2.addClass('black');
        $a3.addClass('black');
        $a4.addClass('black');
    } else {
        $a1.removeClass('black');
        $a2.removeClass('black');

        $a3.removeClass('black');

        $a4.removeClass('black');



        // //
        $a1.addClass('white');
        $a2.addClass('white');
        $a3.addClass('white');
        $a4.addClass('white');
    }

});
//////////////////////////////
///////////////////////////////borders working slightly
// $("#firstswitch").on("click", function () {

//     var $a1 = $('.flex-name').children();
//     var $a2 = $('.flex-bio').children();
//     var $a3 = $('.button-area').children();
//     var $a4 = $('.button-area1').children();

//     $a1.toggleClass('rectangle');
//     $a2.toggleClass('rectangle');
//     $a3.toggleClass('rectangle');
//     $a4.toggleClass('rectangle');

// });
////////////////////////////
$("#firstswitch").on("click", function () {
    var $a3 = $('.button-area');
    var $a4 = $('.button-area1');
    $a3.toggleClass('rectangle');
    $a4.toggleClass('rectangle');

});
////////////////////////////////////
///////////////////////////////borders working slightly

// $("#secondswitch").on("click", function () {
//     console.log("mother fucker2");
//     var $a1 = $('.flex-name').children();
//     var $a2 = $('.flex-bio').children();
//     var $a3 = $('.button-area').children();
//     var $a4 = $('.button-area1').children();

//     $a1.toggleClass('rounded');
//     $a2.toggleClass('rounded');
//     $a3.toggleClass('rounded');
//     $a4.toggleClass('rounded');

// });














////////////////////
$("#secondswitch").on("click", function () {
    var $a3 = $('.button-area');
    var $a4 = $('.button-area1');
    $a3.toggleClass('rounded');
    $a4.toggleClass('rounded');

});


////////////////////////////////
// $("#full").on("click", function () {
//     var $a1 = $('.flex-name');
//     var $a2 = $('.flex-bio');
//     var $a3 = $('.button-area');
//     var $a4 = $('.button-area1');
//     $a3.addClass('fullwhite');
//     $a4.addClass('fullwhite');
//     $a3.addClass('red');
//     $a4.addClass('red');


// });