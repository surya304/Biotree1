$(function () {
    createpreview();
    createpreview1();
    //////////////////////////

    $("#gallery-photo-add").on("click", function () {

        $('.flex-image').append(`<div class="gallery"></div>`);

    });
    var imagesPreview = function (input, placeToInsertImagePreview) {

        if (input.files) {
            var filesAmount = input.files.length;

            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();

                reader.onload = function (event) {
                    $($.parseHTML('<img class="roundimage mx-auto d-block">')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
                }

                reader.readAsDataURL(input.files[i]);
            }
        }

    };

    $('#gallery-photo-add').on('change', function () {
        imagesPreview(this, 'div.gallery');
    });




    //////////////////////////////

    var $appendData = $('#sortable');
    $('.hello').on('click', function () {


        // var img = $(this).find('.image1').attr("src");
        var img = $(this).find('.image1').html();

        var id = $(this).find('.first').html();

        var listItemToAdda = makelist(img, id);
        $appendData.append(listItemToAdda);
        createpreview();










        // var listItemToAdda1 = makeNewListItema1(img, id);



        // $('.button-area').append(listItemToAdda1);


    });

    function createpreview() {
        // var createpreview = function () {
        $('.button-area').empty();
        var $appendData1 = $('#sortable').children();
        // console.log($appendData1);
        for (let index = 0; index < $appendData1.length; index++) {

            var $dynamic = $appendData1.eq(index);
            // console.log($dynamic);

            // const element = $dynamic.find('.image1').attr('src');
            var element = $dynamic.find('.image1').html();
            // console.log(element);
            const elementp = $dynamic.children().children().find('.findp').html();
            const href = $dynamic.children().find('.ip').val();

            // console.log(element);   

            // console.log(elementp);
            var listItemToAdda1 = makeNewListItema1(element, elementp, href);
            $('.button-area').append(listItemToAdda1);


        }
    }
    // var makeNewListItema1 = function (add, troop, link) {
    function makeNewListItema1(add, troop, link) {


        // console.log(add, troop, input);
        // console.log(troop);

        var $allData = `<a  href="` + link + `" id="` + troop + `"><i class="` + add + `" class="rounded-circle image1" ></i></a>`;
        return $allData;

    }

    var makelist = function (add, troop) {

        var $allData = `<div class="sortableitem" id="` + troop + `"><li id="` + troop + `">

    <div class="row justify-content-left nolo">
    <div class="col-md-1 col-1 text-center defaultlink " style="padding-top:5px;">
    <i class="fa fa-arrows" aria-hidden="true" style="font-size:15px;"></i>
      
        </div>
    <div class="col-md-1 col-1 u-mb-small  text-center"> 
    <i class="` + add + `" class="rounded-circle image1" style="color:blue;padding-top:5px"></i>
    <span class="image1" style="display:none">` + add + `</span>
    </div><div class="col-md-8 col-7 u-mb-small "><label class="c-field__label u-hidden-visually " for="input1">Label</label>
    <input class="c-input ip" id="input1" type="text" placeholder="place your Link here"> 
    <span class="findp" style="display:none">` + troop + `</span>
    </div>
   
     <div class="col-md-1 col-1 text-center"> 
    <a class="btn del"> <i class="fa fa-trash-o" aria-hidden="true"></i></a>
    <span class="find" style="display:none">` + troop + `</span></div>

    </div></li></div>`;

        return $allData;

    }
    $appendData.on("click", ".del", function () {
        var bolo = $(this).parentsUntil('.sortableitem').parent().remove();

        createpreview();


    });
    $appendData.on("keyup", ".ip", function (e) {
        if (e.keyCode == 13) {
            var inputData = $(this).val();
            console.log(inputData);
            var id = $(this).next().html();
            console.log(id);
            var preview = $('.button-area').children();
            console.log(preview);

            for (let index = 0; index < preview.length; index++) {
                const element1 = preview[index].getAttribute('id');
                var element2 = preview[index];


                console.log(element1);

                if (id === element1) {
                    // element1.setAttribute('href', inputData);
                    element2.setAttribute('href', inputData);


                } else {
                    console.log("no");
                }
            }



        }



    });
    ///////////////////////sortable
    $("#sortable")
        .sortable({
            revert: true,
            connectWith: ".sortable",
            stop: function (event, ui) {



                createpreview();

            }


        });

    ///////////////////////////

    //////////////////////////////////////second Links///////////////////////////////////////////////////////////////////////////////////////
    $("#sortable1")
        .sortable({
            revert: true,
            connectWith: ".sortable",
            stop: function (event, ui) {



                createpreview1();

            }


        });
    var $data = $('#sortable1');
    var iCnt = 0;
    $('.linkbtn').on('click', function () {

        iCnt = iCnt + 1;
        var $data1 = ` <div class="row sortableitem">
   <span class="find" style="display:none">` + iCnt + `</span>
   <div class="col-md-1" style=" margin-left: 20px;">
   <a class="btn ">
   <i class="fa fa-arrows" aria-hidden="true" style="font-size:15px;"></i>
 
</a>
   </div>
   <div class="col-md-5 u-mb-small">
      <div class="c-field ">
         <label class="c-field__label u-hidden-visually" for="input1">Label</label>
         <input class="c-input link" id="input1" type="text" placeholder="place your link here">
         <span class="find" style="display:none">` + iCnt + `</span>
      </div>
   </div>
   <div class="col-md-4 u-mb-small">
      <div class="c-field ">
         <label class="c-field__label u-hidden-visually" for="input1">Label</label>
         <input class="c-input title" id="input1" type="text" placeholder="place your title here" >
         <span class="find" style="display:none">` + iCnt + `</span>
      </div>
   </div>
  
   <div class="col-md-1 u-mb-small">
      <a class="btn del3" ;padding-bottom: 10px;">
         <i class="fa fa-trash-o" aria-hidden="true"></i>
      </a>
   </div>
</div>`;

        $data.append($data1);
        createpreview1();

    });
    ////////////////

    //////////////

    // var createpreview1 = function () {
    function createpreview1() {
        $('.button-area1').empty();

        var oyy = $('#sortable1').children();
        console.log(oyy);

        for (let index = 0; index < oyy.length; index++) {

            var $dynamic = oyy.eq(index);
            console.log($dynamic);
            // var number = $dynamic.children().find('.find').html();
            // console.log(number);

            const href = $dynamic.children().find('.link').val();
            console.log(href);

            const title = $dynamic.children().find('.title').val();
            console.log(title);

            // var listItemToAdda1 = makeNewListItemLink(number, href, title);
            // $('.button-area1').append(listItemToAdda1);
            var listItemToAdda1 = makeNewListItemLink(href, title);
            $('.button-area1').append(listItemToAdda1);





        }



    }
    $data.on("click", ".del3", function () {
        var bolo = $(this).parent().parent().remove();
        console.log(bolo);

        createpreview1();

    });
    //////////////////////////////////
    // var createpreview = function () {
    //     $('.button-area').empty();
    //     var $appendData1 = $('#sortable').children();

    //     for (let index = 0; index < $appendData1.length; index++) {

    //         var $dynamic = $appendData1.eq(index);


    //         const element = $dynamic.find('.image1').attr('src');

    //         const elementp = $dynamic.children().children().find('.findp').html();
    //         const href = $dynamic.children().find('.ip').val();



    //         var listItemToAdda1 = makeNewListItema1(element, elementp, href);
    //         $('.button-area').append(listItemToAdda1);


    //     }
    // }

    //////////////////////////////////////////


    // var makeNewListItemLink = function (number, href, title) {
    // function makeNewListItemLink(number, href, title) {

    //     var $allData = `<a href="` + href + `" id="` + number + `">` + title + `</a>`;
    //     return $allData;

    // }
    function makeNewListItemLink(href, title) {

        var $allData = `<a href="` + href + `" >` + title + `</a>`;
        return $allData;

    }




    $data.on("keyup", ".link", function (e) {

        // if (e.keyCode == 13) {

        //     console.log("hello");
        //     var inputData = $(this).val();
        //     console.log(inputData);
        //     var id = $(this).next().html();
        //     console.log(id);
        //     var preview = $('.button-area1').children();
        //     console.log(preview);

        //     for (let index = 0; index < preview.length; index++) {
        //         const element1 = preview[index].getAttribute('id');
        //         var element2 = preview[index];


        //         console.log(element1);

        //         if (id === element1) {
        //             element2.setAttribute('href', inputData);


        //         } else {
        //             console.log("no");
        //         }
        //     }



        // }
        createpreview1();


    });
    $data.on("keyup", ".title", function (e) {


        // if (e.keyCode == 13) {
        //     console.log("hello");

        //     var inputData = $(this).val();
        //     console.log(inputData);
        //     var id = $(this).next().html();
        //     console.log(id);
        //     var preview = $('.button-area1').children();
        //     console.log(preview);

        //     for (let index = 0; index < preview.length; index++) {
        //         const element1 = preview[index].getAttribute('id');
        //         var element2 = preview[index];


        //         console.log(element1);
        //         console.log(element2);


        //         if (id === element1) {

        //             element2.append(inputData);


        //         } else {
        //             console.log("no");
        //         }
        //     }
        // }
        createpreview1();


    });

    $data.on("keydown", ".title", function () {

        // $('.button-area1').children().remove();
        // createpreview1();

    });


    $data.on("keydown", ".link", function (e) {
        // $('.button-area1').children().remove();
        // createpreview1();

    });




















    ///////////////////////////////////////////////////////////////style preview
    ///////////////////////////////flex name
    $style1 = $('.flex-name');
    $("#alert").hide();
    $('.bioname').on("keyup", function (e) {

        var a1 = $(this).val();

        var a2 = foo(a1);
        $style1.append(a2);

        if (a1.length < 5) {
            check1();
            $("#alert").hide();

        } else {
            $("#alert").show();
            $style1.empty();
        }



    });




    function check1() {

        var deli = $style1.empty();
        console.log(deli);
        var val = $('.bioname').val();
        console.log(val);
        var a2 = foo(val);
        $style1.append(a2);


    }

    function foo(params) {
        var data = `<div class="title">` + params + `</div>`;
        return data;

    }

    ///////////////////////////////////////////////////////////////////////

    $style2 = $('.flex-bio');
    $("#alert1").hide();
    $('.bio').on("keyup", function (e) {


        var a1 = $(this).val();
        var a2 = foo1(a1);
        $style2.append(a2);
        if (a1.length < 10) {
            check2();
            $("#alert1").hide();

        } else {
            $("#alert1").show();
            $style2.empty();
        }


    });

    function check2() {
        $style2.empty();
        var val = $('.bio').val();

        var a2 = foo1(val);
        $style2.append(a2);


    }

    function foo1(params) {

        var data = `<div>` + params + `</div>`;
        return data;

    }



    /////////////////////////////////////////////////////////////////////responsive



















































});